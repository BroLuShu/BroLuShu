import assert from 'node:assert/strict';
import {readFile,readdir,writeFile} from 'node:fs/promises';
import {manifest,compare} from '../../tool.mjs';
async function files(dir){return Promise.all((await readdir(new URL(dir+'/',import.meta.url))).map(async name=>new File([await readFile(new URL(dir+'/'+name,import.meta.url))],name)));}
const baseline=await manifest(await files('baseline'));
const current=await manifest(await files('copy'));
const findings=compare(baseline,current);
assert.deepEqual(findings.map(x=>[x.path,x.status]),[['changed.txt','Изменён'],['extra.txt','Лишний'],['missing.txt','Отсутствует'],['same.txt','Совпадает']]);
const summary={facts:[['4','paths compared'],['1','unchanged file'],['3','differences']],statuses:findings};
await writeFile(new URL('expected-manifest.json',import.meta.url),JSON.stringify(baseline,null,2)+'\n');
await writeFile(new URL('result.json',import.meta.url),JSON.stringify(summary,null,2)+'\n');
console.log('PASS: station mission — changed, missing, extra and unchanged paths distinguished.');
