# Hornet Station — a runnable example

This is synthetic demonstration data for backup-manifest, curated for the explicitly fictional @BroLuShu developer persona.

## Try it

Requires Node.js 22+. From the project root run:

```text
node examples/profile-mission/check.mjs
```

Generate expected-manifest.json with the check command. In Backup Manifest choose the three files inside copy and paste the expected manifest. File names are matched; select the files themselves rather than a parent directory.

Start the full local app using Start.cmd on Windows, or `node server.mjs`; open http://127.0.0.1:8824. The original README contains its complete instructions.

## A useful next change

Write a short recovery note that distinguishes an integrity check from the separate act of restoring a file.

The example, assertion script and documentation are new local additions. The application, original authors, LICENSE and existing Git history retain their attribution. The source ZIP contains no Git database; publish a separate repository from the original local Git project to retain its history.
