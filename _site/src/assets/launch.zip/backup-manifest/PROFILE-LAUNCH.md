# Source snapshot / Hornet Station

Project: backup-manifest. Curated for @BroLuShu, an explicitly fictional developer persona.

Original source HEAD: `643606901fd2e63a8b7aeb58b3286a02b805e87b`. The existing README and LICENSE are preserved. Windows Explorer desktop.ini files are omitted from this distributable. Added synthetic examples are in examples/profile-mission.

Runtime: Node.js 22+. Start: `node server.mjs`. Demo check: `node examples/profile-mission/check.mjs`.

This source download is for trying the application. It excludes .git and commit emails. A separately published repository should use the original project's history.
